//
//  AppDelegate.swift
//  DocuCore
//
//  Created by Sudhanshu on 01/05/25.
//



import UIKit

@IBDesignable
class DesignableUITextField: UITextField {
    
    
    private let gradientLayer = CAGradientLayer()
    
    override func layoutSubviews() {
        super.layoutSubviews()
        applyGradient()
    }
    
    
    
    override func leftViewRect(forBounds bounds: CGRect) -> CGRect {
        var textRect = super.leftViewRect(forBounds: bounds)
        textRect.origin.x += leftPadding
        return textRect
    }
    
    override func rightViewRect(forBounds bounds: CGRect) -> CGRect {
        var textRect = super.rightViewRect(forBounds: bounds)
        
        textRect.origin.x -= rightPadding
        return textRect
    }
    
    
    
    @IBInspectable var leftImage: UIImage? {
        didSet {
            updateView()
        }
    }
    
    @IBInspectable var radious: CGFloat = 5 {
        didSet {
            self.layer.cornerRadius = radious
            self.layer.masksToBounds = true
        }
    }
        
    @IBInspectable var borderWidth: CGFloat = 1 {  // Border width
        didSet {
            self.layer.borderWidth = borderWidth
        }
    }
    
    @IBInspectable var borderColor: UIColor = .gray { // Border color
        didSet {
            self.layer.borderColor = borderColor.cgColor
        }
    }
    
    @IBInspectable var leftPadding: CGFloat = 0
    
    @IBInspectable var color: UIColor = UIColor.lightGray {
        didSet {
            updateView()
        }
    }
    
    @IBInspectable var isPasswordField: Bool = false {
        didSet {
            setupEyeButton()
        }
    }
    
    
    
   
    
    @IBInspectable var rightPadding: CGFloat = 8 // Padding for the eye button
    
    
    
    
    @IBInspectable var startColor: UIColor = .blue {
        didSet {
            applyGradient()
        }
    }
    
    @IBInspectable var endColor: UIColor = .cyan {
        didSet {
            applyGradient()
        }
    }
    
    @IBInspectable var isHorizontalGradient: Bool = true {
        didSet {
            applyGradient()
        }
    }
    
    
    
    
    
    
    
    private var eyeButton: UIButton = UIButton(type: .custom)
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupEyeButton()
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setupAppearance()
    }
    
    
    private func setupAppearance() {
        setupEyeButton()
       
        applyGradient()
    }
    
    
    
    
    private func setupEyeButton() {
        if isPasswordField {
            // Make sure secure entry is enabled
            isSecureTextEntry = true
            
            eyeButton.setImage(UIImage(systemName: "eye.slash.fill"), for: .normal) // Closed eye icon
            eyeButton.setImage(UIImage(systemName: "eye.fill"), for: .selected) // Open eye icon
            eyeButton.tintColor = color

            let buttonWidth: CGFloat = 30
            let buttonHeight: CGFloat = 20
            let padding: CGFloat = rightPadding

            eyeButton.frame = CGRect(x: 0, y: 0, width: buttonWidth + padding, height: buttonHeight)
            eyeButton.imageEdgeInsets = UIEdgeInsets(top: 0, left: padding / 2, bottom: 0, right: padding / 2)

            eyeButton.addTarget(self, action: #selector(togglePasswordVisibility), for: .touchUpInside)

            rightView = eyeButton
            rightViewMode = .always
        } else {
            isSecureTextEntry = false
            rightView = nil
            rightViewMode = .never
        }
    }
    
    
    
    
    
    
    @objc private func togglePasswordVisibility() {
        isSecureTextEntry.toggle()
        eyeButton.isSelected = !isSecureTextEntry
    }
    
    
    
    
    
    
    func updateView() {
        if let image = leftImage {
            leftViewMode = UITextField.ViewMode.always
            let imageView = UIImageView(frame: CGRect(x: 0, y: 0, width: 16, height: 20))
            imageView.contentMode = .scaleAspectFit
            imageView.image = image
            imageView.tintColor = color
            leftView = imageView
        } else {
            leftViewMode = UITextField.ViewMode.never
            leftView = nil
        }
        
        
        // Placeholder text color
        attributedPlaceholder = NSAttributedString(
            string: placeholder ?? "",
            attributes: [NSAttributedString.Key.foregroundColor: color]
        )
    }
    
    
    
    // MARK: - Gradient Function
    private func applyGradient() {
        gradientLayer.frame = bounds
        gradientLayer.colors = [startColor.cgColor, endColor.cgColor]
        gradientLayer.startPoint = CGPoint(x: 0, y: 0)
        gradientLayer.endPoint = isHorizontalGradient ? CGPoint(x: 1, y: 0) : CGPoint(x: 0, y: 1)
        gradientLayer.cornerRadius = radious
        
        if gradientLayer.superlayer == nil {
            layer.insertSublayer(gradientLayer, at: 0)
        }
    }
}
