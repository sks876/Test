//
//  ProductCell.swift
//  DocuCore
//
//  Created by Sudhanshu on 03/05/25.
//

import UIKit

class ProductCell: UITableViewCell {
    
    
    
    
    @IBOutlet weak var idLabel: UILabel!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var contentVIew: UIView!
    
    
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        
        contentVIew.layer.cornerRadius = 8
        contentVIew.layer.shadowColor = UIColor.black.cgColor
        contentVIew.layer.shadowOpacity = 0.25
        contentVIew.layer.shadowOffset = CGSize(width: 0, height: 2)
        contentVIew.layer.shadowRadius = 4
        
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
