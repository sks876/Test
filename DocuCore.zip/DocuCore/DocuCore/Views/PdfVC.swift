//
//  PdfVC.swift
//  DocuCore
//
//  Created by Sudhanshu on 01/05/25.
//


// https://fssservices.bookxpert.co/GeneratedPDF/Companies/nadc/2024-2025/BalanceSheet.pdf



import UIKit
import PDFKit
import Network

class PdfVC: UIViewController {

    @IBOutlet weak var pdfContainerView: UIView!
    @IBOutlet weak var internetLabel: UILabel!

    let url = "https://fssservices.bookxpert.co/GeneratedPDF/Companies/nadc/2024-2025/BalanceSheet.pdf"
    let monitor = NWPathMonitor()
    let queue = DispatchQueue(label: "NetworkMonitor")

    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        internetLabel.isHidden = true
        checkInternetAndLoadPDF()
        
        
    }
    
    
  
    
    
    
    

    func checkInternetAndLoadPDF() {
        monitor.pathUpdateHandler = { path in
            DispatchQueue.main.async {
                if path.status == .satisfied {
                    self.internetLabel.isHidden = true
                    self.loadPDF(from: self.url)
                } else {
                    self.internetLabel.isHidden = false
                    self.showAlert(title: "No Internet", message: "Please check your internet connection.")
                }
            }
        }
        monitor.start(queue: queue)
    }

    
    
    func loadPDF(from urlString: String) {
        guard let url = URL(string: urlString) else {
            showAlert(title: "Invalid URL", message: "The provided PDF URL is not valid.")
            return
        }

        let pdfView = PDFView(frame: pdfContainerView.bounds)
        pdfView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        pdfView.autoScales = true
        pdfContainerView.addSubview(pdfView)

        let task = URLSession.shared.dataTask(with: url) { data, _, error in
            if let error = error {
                DispatchQueue.main.async {
                    self.showAlert(title: "Load Failed", message: "Failed to load PDF: \(error.localizedDescription)")
                }
                return
            }

            guard let data = data, let document = PDFDocument(data: data) else {
                DispatchQueue.main.async {
                    self.showAlert(title: "Invalid PDF", message: "The data is not a valid PDF file.")
                }
                return
            }

            DispatchQueue.main.async {
                pdfView.document = document
            }
        }
        task.resume()
    }
    
    

    func showAlert(title: String, message: String) {
        let alertVC = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alertVC.addAction(UIAlertAction(title: "OK", style: .default))
        present(alertVC, animated: true)
    }
    
    

    deinit {
        monitor.cancel()
    }
    
    
}
