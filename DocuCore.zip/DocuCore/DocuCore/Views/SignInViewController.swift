//
//  ViewController.swift
//  DocuCore
//
//  Created by Sudhanshu on 01/05/25.
//

import UIKit
import FirebaseAuth
import GoogleSignIn
import FirebaseCore

class SignInViewController: UIViewController {
    
    @IBOutlet weak var signInButton: GIDSignInButton!
    @IBOutlet weak var userImage: UIImageView!
    @IBOutlet weak var textDetailsLabel: UILabel!
    @IBOutlet weak var signoutButton: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleGoogleSignIn))
        signInButton.addGestureRecognizer(tapGesture)
    }
    
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let currentUser = Auth.auth().currentUser {
        
            signoutButton.isHidden = false
            signInButton.isHidden = true
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.3, execute: {
                self.displaySignedInUser()
            })
        } else {
            
            signoutButton.isHidden = true
            signInButton.isHidden = false
            textDetailsLabel.text = "Not signed in"
            userImage.image = nil
        }
        
        
    }

    
    
    
    
    @IBAction func signOutButtonTapped(_ sender: Any) {
        do {
            try Auth.auth().signOut()
            GIDSignIn.sharedInstance.signOut()
            
            // Clear UI
            textDetailsLabel.text = "Signed out"
            userImage.image = nil
            signInButton.isHidden = false
            signoutButton.isHidden = true
            
            print("✅ User signed out")
        } catch let error {
            print("❌ Error signing out: \(error.localizedDescription)")
        }
    }

    

    
    
    
    @objc func handleGoogleSignIn() {
        guard let clientID = FirebaseApp.app()?.options.clientID else {
            print("❌ Firebase clientID missing")
            return
        }

        let config = GIDConfiguration(clientID: clientID)
        GIDSignIn.sharedInstance.configuration = config

        GIDSignIn.sharedInstance.signIn(withPresenting: self) { result, error in
            if let error = error {
                print("❌ Google Sign-In error: \(error.localizedDescription)")
                return
            }

            guard let googleUser = result?.user,
                  let idToken = googleUser.idToken?.tokenString else {
                print("❌ Google auth token missing")
                return
            }

            let credential = GoogleAuthProvider.credential(
                withIDToken: idToken,
                accessToken: googleUser.accessToken.tokenString
            )

            Auth.auth().signIn(with: credential) { authResult, error in
                if let error = error {
                    print("❌ Firebase sign-in failed: \(error.localizedDescription)")
                } else if let user = authResult?.user {
                    print("Signed in!")
                    print("UID: \(user.uid)")
                    print("Email: \(user.email ?? "No email")")
                   
                    let profile = FirebaseUserProfile(
                        uid: user.uid,
                        email: user.email ?? "No email",
                        displayName: user.displayName ?? "No name",
                        photoURL: user.photoURL?.absoluteString ?? "No photo",
                        phoneNumber: user.phoneNumber ?? "No phone",
                        creationDate: user.metadata.creationDate?.description ?? "N/A",
                        lastSignInDate: user.metadata.lastSignInDate?.description ?? "N/A"
                    )

                   
                    UserCoredataManager.shared.insertUser(profile: profile)
                    
                
                    DispatchQueue.main.async {
                        self.displaySignedInUser()
                    }
                    
                }
            }
        }
    }

}






extension SignInViewController {
    
    func displaySignedInUser() {
       
        let users = UserCoredataManager.shared.fetchUsers()
        guard let latestUser = users.last else {
            textDetailsLabel.text = "No user found"
            return
        }

       
        textDetailsLabel.text = """
        Name: \(latestUser.displayName ?? "No name")
        Email: \(latestUser.email ?? "No email")
        Phone: \(latestUser.phoneNumber ?? "No phone")
        Last Sign In: \(latestUser.lastSignInDate ?? "N/A")
        """

        
        if let urlString = latestUser.photoURL,
           let url = URL(string: urlString) {
            URLSession.shared.dataTask(with: url) { data, _, error in
                if let data = data, error == nil {
                    DispatchQueue.main.async {
                        self.userImage.image = UIImage(data: data)
                        self.userImage.layer.cornerRadius = self.userImage.frame.width / 2
                        self.userImage.clipsToBounds = true
                    }
                }
            }.resume()
        }
    }

    
}
