//
//  UpdateProductVC.swift
//  DocuCore
//
//  Created by Sudhanshu on 04/05/25.
//

import UIKit

@available(iOS 14.0, *)
class UpdateProductVC: UIViewController {

    @IBOutlet weak var productText: UITextField!
    @IBOutlet weak var colorText: UITextField!
    @IBOutlet weak var capacityText: UITextField!
    @IBOutlet weak var productIdLabel: UILabel!
    @IBOutlet weak var notifySwitch: UISwitch!
    
    @IBOutlet weak var topView: UIView!
    @IBOutlet weak var updateButton: UIButton!
    @IBOutlet weak var deletebutton: UIButton!

    var product: Product!

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        
        topView.layer.cornerRadius = 4
        topView.layer.shadowColor = UIColor.black.cgColor
        topView.layer.shadowOpacity = 0.25
        topView.layer.shadowOffset = CGSize(width: 0, height: 2)
        topView.layer.shadowRadius = 4
        topView.layer.masksToBounds = false
        
        
        updateButton.layer.shadowColor = UIColor.black.cgColor
        updateButton.layer.shadowOpacity = 0.25
        updateButton.layer.shadowOffset = CGSize(width: 0, height: 2)
        updateButton.layer.shadowRadius = 4
        
        deletebutton.layer.shadowColor = UIColor.black.cgColor
        deletebutton.layer.shadowOpacity = 0.25
        deletebutton.layer.shadowOffset = CGSize(width: 0, height: 2)
        deletebutton.layer.shadowRadius = 4
       
        
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        let isNotifyEnabled = UserDefaults.standard.bool(forKey: "isNotifyEnabled")
        notifySwitch.isOn = isNotifyEnabled
    }

    
    private func setupUI() {
        productIdLabel.text = "ID: \(product.id ?? "N/A")"
        productText.text = product.name
        colorText.text = product.color
        capacityText.text = product.capacity
    }

    
    
    @IBAction func notifySwitchChanged(_ sender: UISwitch) {
        UserDefaults.standard.set(sender.isOn, forKey: "isNotifyEnabled")
    }
    
    
    
    @IBAction func updateButtonTapped(_ sender: Any) {
        guard let product = product else {
            showAlert(title: "Error", message: "No product found to update.")
            return
        }

        guard let name = productText.text, !name.isEmpty,
              let color = colorText.text,
              let capacity = capacityText.text else {
            showAlert(title: "Missing Info", message: "Please fill in all fields.")
            return
        }

      
        ProductCoreDataManager.shared.upsertProduct(
            id: product.id ?? "",
            name: name,
            color: color,
            capacity: capacity
        )

      
        showAlert(title: "Updated", message: "Product details updated successfully.") {
            self.navigationController?.popViewController(animated: true)
        }
    }
    
    

    @IBAction func deleteButtonTapped(_ sender: Any) {
        guard let product = product else { return }

        ProductCoreDataManager.shared.deleteProduct(product)

       
        if notifySwitch.isOn {
            let content = UNMutableNotificationContent()
            
            let name  = productText.text
            content.title = "Product Deleted"
            content.body = "“\(name ?? "Unknown")” has been removed."
            content.sound = .default

            let request = UNNotificationRequest(
                identifier: UUID().uuidString,
                content: content,
                trigger: UNTimeIntervalNotificationTrigger(timeInterval: 1, repeats: false)
            )

            UNUserNotificationCenter.current().add(request)
        }

        self.navigationController?.popViewController(animated: true)
    }
    
    
    
    
    func triggerLocalNotification(for product: Product) {
        let content = UNMutableNotificationContent()
        content.title = "Product Deleted"
        content.body = "The product \"\(product.name ?? "Unknown")\" was deleted successfully."
        content.sound = .default

        let request = UNNotificationRequest(
            identifier: UUID().uuidString,
            content: content,
            trigger: UNTimeIntervalNotificationTrigger(timeInterval: 1, repeats: false)
        )

        UNUserNotificationCenter.current().add(request) { error in
            if let error = error {
                print("❌ Failed to add notification: \(error)")
            } else {
                print("🔔 Local notification scheduled.")
            }
        }
    }
    
    
    
    
    

    func showAlert(title: String, message: String, completion: (() -> Void)? = nil) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default) { _ in
            completion?()
        })
        present(alert, animated: true)
    }
    
    
    
}
