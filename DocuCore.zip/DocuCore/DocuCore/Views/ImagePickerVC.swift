//
//  ImagePickerVC.swift
//  DocuCore
//
//  Created by Sudhanshu on 02/05/25.
//

import UIKit
import AVFoundation

class ImagePickerVC: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    @IBOutlet weak var testImageView: UIImageView!
    @IBOutlet weak var btnStack: UIStackView!
    
    var imagePicker = UIImagePickerController()

    override func viewDidLoad() {
        super.viewDidLoad()
        imagePicker.delegate = self
        
        testImageView.isUserInteractionEnabled = true
        testImageView.contentMode = .scaleAspectFit
        testImageView.layer.cornerRadius = 4
        testImageView.clipsToBounds = true
        
        let pinchGesture = UIPinchGestureRecognizer(target: self, action: #selector(handlePinch(_:)))
        testImageView.addGestureRecognizer(pinchGesture)
        
        
        
        for i in btnStack.arrangedSubviews{
            i.layer.shadowColor = UIColor.black.cgColor
            i.layer.shadowOpacity = 0.25
            i.layer.shadowOffset = CGSize(width: 0, height: 2)
            i.layer.shadowRadius = 4
        }
        
        
        
    }
    

    @objc func handlePinch(_ gesture: UIPinchGestureRecognizer) {
        guard let view = gesture.view else { return }

        let currentScale = view.frame.size.width / view.bounds.size.width
        let newScale = currentScale * gesture.scale

        if newScale >= 1 && newScale <= 3 {
            view.transform = view.transform.scaledBy(x: gesture.scale, y: gesture.scale)
        }

        gesture.scale = 1
    }
    

    
    @IBAction func btnCameraTapped(_ sender: Any) {
        openCamera()
    }

   
    @IBAction func btnGalleryTapped(_ sender: Any) {
        if UIImagePickerController.isSourceTypeAvailable(.photoLibrary) {
            imagePicker.sourceType = .photoLibrary
            imagePicker.allowsEditing = false
            present(imagePicker, animated: true, completion: nil)
        } else {
            showAlert(title: "Error", message: "Photo Library not available.")
        }
    }

    
    func openCamera() {
        let status = AVCaptureDevice.authorizationStatus(for: .video)

        switch status {
        case .authorized:
            presentCamera()
        case .notDetermined:
            AVCaptureDevice.requestAccess(for: .video) { granted in
                DispatchQueue.main.async {
                    if granted {
                        self.presentCamera()
                    } else {
                        self.showAlert(title: "Permission Denied", message: "Camera access was denied.")
                    }
                }
            }
        case .denied, .restricted:
            showSettingsAlert()
        @unknown default:
            showAlert(title: "Error", message: "Unknown camera permission status.")
        }
    }

    
    func presentCamera() {
        if UIImagePickerController.isSourceTypeAvailable(.camera) {
            imagePicker.sourceType = .camera
            imagePicker.allowsEditing = false
            present(imagePicker, animated: true, completion: nil)
        } else {
            showAlert(title: "Camera Not Available", message: "This device doesn't support a camera.")
        }
    }

   
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        picker.dismiss(animated: true, completion: nil)
        if let image = info[.originalImage] as? UIImage {
            testImageView.image = image
        }
    }

    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }

    
    func showSettingsAlert() {
        let alert = UIAlertController(title: "Camera Permission", message: "Camera access is denied. Please enable it in Settings.", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        alert.addAction(UIAlertAction(title: "Settings", style: .default, handler: { _ in
            if let settingsURL = URL(string: UIApplication.openSettingsURLString) {
                UIApplication.shared.open(settingsURL)
            }
        }))
        present(alert, animated: true)
    }

   
    func showAlert(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }
    
    
    
}
