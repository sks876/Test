//
//  ListVC.swift
//  DocuCore
//
//  Created by Sudhanshu on 03/05/25.
//

import UIKit
import CoreData



@available(iOS 14.0, *)
class ListVC: UIViewController, UITableViewDelegate {

    @IBOutlet weak var tableView: UITableView!
    
    let url = "https://api.restful-api.dev/objects"
    var products: [Product] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.dataSource = self
        tableView.delegate = self
        tableView.separatorStyle = .none
        
    }

    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        let isDataFetched = UserDefaults.standard.bool(forKey: "isDataFetched")
        if isDataFetched {
            
            loadFromLocalData()
        } else {
            
            fetchDataAndUpdateLocalStore()
            tableView.reloadData()
        }
    }
    
    
    
    func fetchDataAndUpdateLocalStore() {
        fetchDataFromAPI(urlString: url) { (result: Result<[ObjectModel], Error>) in
            DispatchQueue.main.async {
                switch result {
                case .success(let models):
                    ProductCoreDataManager.shared.deleteAllProducts()
                    models.forEach {
                        ProductCoreDataManager.shared.upsertProduct(
                            id: $0.id ?? "",
                            name: $0.name,
                            color: $0.data?.color,
                            capacity: $0.data?.capacity
                        )
                    }

                    UserDefaults.standard.set(true, forKey: "isDataFetched")
                    self.loadFromLocalData()

                case .failure(let error):
                    self.showAlert(title: "Error", message: error.localizedDescription)
                }
            }
        }
    }
    
    
    
    
    
    func loadFromLocalData() {
        products = ProductCoreDataManager.shared.fetchAllProducts()
        tableView.reloadData()
    }

    
    
    
    func fetchDataFromAPI<Model: Codable>(urlString: String, completion: @escaping (Result<[Model], Error>) -> Void) {
        guard let url = URL(string: urlString) else {
            let error = NSError(domain: "", code: -1, userInfo: [NSLocalizedDescriptionKey: "Malformed URL"])
            completion(.failure(error))
            return
        }

        URLSession.shared.dataTask(with: url) { data, _, error in
            if let error = error {
                completion(.failure(error))
                return
            }

            guard let data = data else {
                let error = NSError(domain: "", code: -2, userInfo: [NSLocalizedDescriptionKey: "No data received"])
                DispatchQueue.main.async {
                    completion(.failure(error))
                }
                return
            }

            do {
                let decoded = try JSONDecoder().decode([Model].self, from: data)
                completion(.success(decoded))
            } catch {
                completion(.failure(error))
            }
        }.resume()
    }
    
    
    
    
    func showAlert(title: String, message: String) {
        DispatchQueue.main.async {
            let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default))
            self.present(alert, animated: true)
        }
    }
    
    
    
}




@available(iOS 14.0, *)
extension ListVC: UITableViewDataSource {

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return products.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        let cell = tableView.dequeueReusableCell(withIdentifier: "ProductCell", for: indexPath) as! ProductCell

        let product = products[indexPath.row]
        
        cell.nameLabel.text = "\(product.name ?? "")\n\(product.color ?? "Not")\n\(product.capacity ?? "Not")"
        cell.idLabel.text = "ID: \(product.id ?? "")"
       
        return cell
    }
    
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        100
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "UpdateProductVC") as! UpdateProductVC
        vc.product = products[indexPath.row]
        
        navigationController?.pushViewController(vc, animated: true)
    }
    
}



