//
//  UserCoredataManager.swift
//  DocuCore
//
//  Created by Sudhanshu on 01/05/25.
//

import Foundation
import CoreData

class UserCoredataManager {
    
    static let shared = UserCoredataManager()
    
    // MARK: - Persistent Container
    lazy var persistentContainer: NSPersistentContainer = {
        let container = NSPersistentContainer(name: "DocuCore") // Replace with your .xcdatamodeld file name
        container.loadPersistentStores { (_, error) in
            if let error = error {
                fatalError("❌ Core Data load error: \(error.localizedDescription)")
            }
        }
        return container
    }()
    
    var context: NSManagedObjectContext {
        return persistentContainer.viewContext
    }
    
    // MARK: - Save Context
    func saveContext() {
        if context.hasChanges {
            do {
                try context.save()
                print("✅ Context saved.")
            } catch {
                print("❌ Failed to save context: \(error.localizedDescription)")
            }
        }
    }
    
    // MARK: - Insert User
    func insertUser(profile: FirebaseUserProfile) {
        let user = UserDetails(context: context)
        user.uid = UUID()
        user.displayName = profile.displayName
        user.email = profile.email
        user.photoURL = profile.photoURL
        user.phoneNumber = profile.phoneNumber
        user.creationDate = profile.creationDate
        user.lastSignInDate = profile.lastSignInDate
        saveContext()
    }
    
    // MARK: - Fetch All Users
    func fetchUsers() -> [UserDetails] {
        let request: NSFetchRequest<UserDetails> = UserDetails.fetchRequest()
        do {
            return try context.fetch(request)
        } catch {
            print("❌ Failed to fetch users: \(error.localizedDescription)")
            return []
        }
    }
    
    // MARK: - Delete All Users
    func deleteAllUsers() {
        let users = fetchUsers()
        for user in users {
            context.delete(user)
        }
        saveContext()
    }
    
    // MARK: - Update User (Example by Email)
    func updateUser(email: String, newDisplayName: String) {
        let request: NSFetchRequest<UserDetails> = UserDetails.fetchRequest()
        request.predicate = NSPredicate(format: "email == %@", email)
        
        do {
            let results = try context.fetch(request)
            if let user = results.first {
                user.displayName = newDisplayName
                saveContext()
            }
        } catch {
            print("❌ Update error: \(error.localizedDescription)")
        }
    }
}
