//
//  ProductCoreDataManager.swift
//  DocuCore
//
//  Created by Sudhanshu on 03/05/25.
//


import Foundation
import CoreData
import UIKit

@available(iOS 14.0, *)
class ProductCoreDataManager {

    static let shared = ProductCoreDataManager()

    private let context: NSManagedObjectContext

    private init() {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        context = appDelegate.persistentContainer.viewContext
    }

    // MARK: - Save or Update Product (Upsert by id)
    func upsertProduct(id: String, name: String?, color: String?, capacity: String?) {
        let request: NSFetchRequest<Product> = Product.fetchRequest()
        request.predicate = NSPredicate(format: "id == %@", id)

        do {
            let results = try context.fetch(request)
            if let existingProduct = results.first {
                // Update
                existingProduct.name = name
                existingProduct.color = color
                existingProduct.capacity = capacity
            } else {
                // Insert
                let newProduct = Product(context: context)
                newProduct.id = id
                newProduct.name = name
                newProduct.color = color
                newProduct.capacity = capacity
            }

            try context.save()
            print("✅ Product saved/updated.")

        } catch {
            print("❌ Failed to upsert product: \(error.localizedDescription)")
        }
    }

    // MARK: - Fetch All Products
    func fetchAllProducts() -> [Product] {
        let request: NSFetchRequest<Product> = Product.fetchRequest()

        do {
            return try context.fetch(request)
        } catch {
            print("❌ Failed to fetch products: \(error.localizedDescription)")
            return []
        }
    }

    // MARK: - Delete Specific Product
    func deleteProduct(_ product: Product) {
        context.delete(product)
        do {
            try context.save()
            print("🗑️ Product deleted.")
        } catch {
            print("❌ Failed to delete product: \(error.localizedDescription)")
        }
    }

    // MARK: - Delete All Products
    func deleteAllProducts() {
        let fetchRequest: NSFetchRequest<NSFetchRequestResult> = Product.fetchRequest()
        let deleteRequest = NSBatchDeleteRequest(fetchRequest: fetchRequest)

        do {
            try context.execute(deleteRequest)
            try context.save()
            print("🧹 All products deleted.")
        } catch {
            print("❌ Failed to delete all products: \(error.localizedDescription)")
        }
    }
}
