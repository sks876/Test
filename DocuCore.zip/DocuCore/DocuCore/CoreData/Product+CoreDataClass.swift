//
//  Product+CoreDataClass.swift
//  DocuCore
//
//  Created by Sudhanshu on 03/05/25.
//
//

import Foundation
import CoreData

@objc(Product)
public class Product: NSManagedObject {

}
