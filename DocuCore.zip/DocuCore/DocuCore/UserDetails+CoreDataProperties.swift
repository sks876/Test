//
//  UserDetails+CoreDataProperties.swift
//  DocuCore
//
//  Created by Sudhanshu on 01/05/25.
//
//

import Foundation
import CoreData


extension UserDetails {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<UserDetails> {
        return NSFetchRequest<UserDetails>(entityName: "UserDetails")
    }

    @NSManaged public var uid: UUID?
    @NSManaged public var displayName: String?
    @NSManaged public var email: String?
    @NSManaged public var photoURL: String?
    @NSManaged public var phoneNumber: String?
    @NSManaged public var creationDate: String?
    @NSManaged public var lastSignInDate: String?

}

extension UserDetails : Identifiable {

}
