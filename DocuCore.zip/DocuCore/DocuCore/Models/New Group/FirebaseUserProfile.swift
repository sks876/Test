//
//  FirebaseUserProfile.swift
//  DocuCore
//
//  Created by Sudhanshu on 01/05/25.
//

import Foundation





struct FirebaseUserProfile {
    let uid: String
    let email: String
    let displayName: String
    let photoURL: String
    let phoneNumber: String
    let creationDate: String
    let lastSignInDate: String
}
