//
//  UserDetails+CoreDataClass.swift
//  DocuCore
//
//  Created by Sudhanshu on 01/05/25.
//
//

import Foundation
import CoreData

@objc(UserDetails)
public class UserDetails: NSManagedObject {

}
